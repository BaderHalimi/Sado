
<div class="footer">
    <div class="row justify-content-between align-items-center">
        <div class="col mt-3">
            <span>{{translate('copyright')}} &copy; {{url('/')}} {{date('Y')}}</span>
        </div>
    </div>
</div>
