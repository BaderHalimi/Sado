<div class="inline-page-menu my-4">
    <ul class="list-unstyled">
        <li class="{{ Request::is('admin/business-settings/email-templates/index') ?'active':'' }}"><a
                href="{{route('admin.business-settings.email-templates.index')}}">{{translate('Seller_registration')}}</a>
        </li>
    </ul>
</div>
